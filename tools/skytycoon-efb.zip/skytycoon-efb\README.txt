SkyTycoon EFB — MSFS In-Game Panel
==================================

Install (copy entire folder):
  %LOCALAPPDATA%\Packages\Microsoft.Limitless_8wekyb3d8bbwe\LocalCache\Packages\Community\skytycoon-efb

IMPORTANT: The Community folder name MUST be exactly "skytycoon-efb" (not vatsim).

After MSFS restart, open the toolbar and select "SkyTycoon EFB".
Log in with your SkyTycoon web account; the panel loads https://skytycoon.info via SSL.
