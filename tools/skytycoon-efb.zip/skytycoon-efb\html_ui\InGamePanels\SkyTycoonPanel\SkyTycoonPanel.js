(function () {
  "use strict";

  var API = "https://skytycoon.info";
  var STORAGE_TOKEN = "skytycoon_efb_token";
  var STORAGE_LANG = "skytycoon_efb_lang";

  var I18N = {
    de: {
      title: "SkyTycoon EFB",
      sub: "Cockpit-Autorisierung erforderlich",
      user: "Username",
      pass: "Password",
      btn: "[ Cockpit-System autorisieren ]",
      err_auth: "Ungültige Zugangsdaten oder keine Lizenz!",
      err_net: "Verbindung zur SSL-Zentrale fehlgeschlagen.",
      tab_disp: "Dispatcher",
      tab_jobs: "Flugbörse",
      tab_fuel: "Kerosin",
      tab_radar: "Radar",
    },
    en: {
      title: "SkyTycoon EFB",
      sub: "Cockpit authorization required",
      user: "Username",
      pass: "Password",
      btn: "[ Authorize System ]",
      err_auth: "Invalid credentials or no license!",
      err_net: "Connection to SSL hub failed.",
      tab_disp: "Dispatcher",
      tab_jobs: "Job market",
      tab_fuel: "Fuel",
      tab_radar: "Radar",
    },
  };

  var TABS = [
    { id: "disp", path: "/flight/dispatcher?mode=msfs_panel" },
    { id: "jobs", path: "/market/jobs?mode=msfs_panel" },
    { id: "fuel", path: "/market/msfs_link?mode=msfs_panel" },
    { id: "radar", path: "/market/radar?mode=msfs_panel" },
  ];

  var lang = (localStorage.getItem(STORAGE_LANG) || "de").slice(0, 2);
  if (lang !== "en") lang = "de";

  function t(key) {
    return (I18N[lang] && I18N[lang][key]) || key;
  }

  function $(id) {
    return document.getElementById(id);
  }

  function applyI18n() {
    $("login-title").textContent = t("title");
    $("login-sub").textContent = t("sub");
    $("lbl-user").textContent = t("user");
    $("lbl-pass").textContent = t("pass");
    $("sky-login-btn").textContent = t("btn");
  }

  function buildToolbar(activeId) {
    var bar = $("sky-toolbar");
    bar.innerHTML = "";
    TABS.forEach(function (tab) {
      var b = document.createElement("button");
      b.type = "button";
      b.textContent = t("tab_" + tab.id);
      if (tab.id === activeId) b.className = "active";
      b.addEventListener("click", function () {
        loadFrame(tab.path, tab.id);
      });
      bar.appendChild(b);
    });
  }

  function sslUrl(path, token) {
    var url = API + path;
    var sep = path.indexOf("?") >= 0 ? "&" : "?";
    url += sep + "efb_token=" + encodeURIComponent(token);
    return url;
  }

  function loadFrame(path, tabId) {
    var token = localStorage.getItem(STORAGE_TOKEN);
    if (!token) {
      showLogin();
      return;
    }
    $("sky-frame").src = sslUrl(path, token);
    buildToolbar(tabId || "disp");
  }

  function showApp() {
    $("sky-login").classList.add("hidden");
    $("sky-app").classList.add("visible");
    loadFrame(TABS[0].path, "disp");
  }

  function showLogin() {
    $("sky-login").classList.remove("hidden");
    $("sky-app").classList.remove("visible");
    $("sky-frame").removeAttribute("src");
  }

  function doLogin() {
    var user = ($("sky-user").value || "").trim();
    var pass = $("sky-pass").value || "";
    $("sky-login-err").textContent = "";
    if (!user || !pass) {
      $("sky-login-err").textContent = t("err_auth");
      return;
    }
    fetch(API + "/api/v1/auth/efb_panel_login", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        username: user,
        password: pass,
        lang: lang,
        source: "msfs_efb",
      }),
    })
      .then(function (r) {
        return r.json().then(function (data) {
          return { ok: r.ok, data: data };
        });
      })
      .then(function (res) {
        if (res.ok && res.data && res.data.ok && res.data.efb_token) {
          localStorage.setItem(STORAGE_TOKEN, res.data.efb_token);
          if (res.data.lang) {
            lang = res.data.lang === "en" ? "en" : "de";
            localStorage.setItem(STORAGE_LANG, lang);
            applyI18n();
          }
          showApp();
          return;
        }
        var msg =
          (res.data && (res.data.detail || res.data.message)) || t("err_auth");
        $("sky-login-err").textContent = msg;
      })
      .catch(function () {
        $("sky-login-err").textContent = t("err_net");
      });
  }

  document.addEventListener("DOMContentLoaded", function () {
    applyI18n();
    $("sky-login-btn").addEventListener("click", doLogin);
    $("sky-pass").addEventListener("keydown", function (e) {
      if (e.key === "Enter") doLogin();
    });
    var saved = localStorage.getItem(STORAGE_TOKEN);
    if (saved) {
      fetch(API + "/api/v1/auth/efb_panel_session", {
        headers: { Authorization: "Bearer " + saved },
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (data) {
          if (data && data.ok) showApp();
          else showLogin();
        })
        .catch(function () {
          showLogin();
        });
    }
  });
})();
